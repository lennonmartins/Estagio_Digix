package com.example.testingweb.carrinho;

public class CarrinhoHibernateDAO implements CarrinhoRepository {

	@Override
	public void salvar(CarrinhoDeCompra carrinho) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buscarPelo(int id) {
		// TODO Auto-generated method stub
		
	}

}
