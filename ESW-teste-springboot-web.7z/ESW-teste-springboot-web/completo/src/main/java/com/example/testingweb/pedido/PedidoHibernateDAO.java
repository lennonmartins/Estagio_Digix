package com.example.testingweb.pedido;

import java.util.List;

public class PedidoHibernateDAO implements PedidoRepository {

	@Override
	public List<Pedido> buscarPelo(int numeroDoPedido) {
		return null;
	}

}
