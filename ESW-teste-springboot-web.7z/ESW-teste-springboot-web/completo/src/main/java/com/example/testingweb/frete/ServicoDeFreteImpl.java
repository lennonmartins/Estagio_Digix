package com.example.testingweb.frete;

public class ServicoDeFreteImpl implements ServicoDeFrete {

	@Override
	public double calcularFretePara(String cepDeOrigem, String cepDeDestino) throws ServicoDeFreteIndisponivel {
		// TODO Auto-generated method stub
		return 0;
	}

}
