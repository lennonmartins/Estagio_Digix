package br.com.digix.salario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalarioApplication.class, args);
	}

}
