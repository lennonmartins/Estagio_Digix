package br.com.digix.salario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
